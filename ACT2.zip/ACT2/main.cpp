/** 
* Compilacion para debug (banderas):  
*    g++ -std=c++17 -g -o main *.cpp 
* Compilacion para ejecucion:  
*    g++ -std=c++17 -O3 -o main *.cpp 
**/
/*
----------------------------------------------------------------------------------------------
// Kevin Alejandro Ramírez Luna
----------------------------------------------------------------------------------------------
Archivo main estructurado y basado en la POO. Toma en cuenta los archivo .h para hacer la busqueda de los datos en una bitacora, tomado como base y seleccionado los rangos de fechas dadas por el usuario. 

El código usa la clase DoublyLinkedList para almacenar los registros y realizar una busqueda de datos. A mismo modo, implementa algoritmos como merge sort y la búsqueda binaria para ordenar y buscar los registros dentro de la bitacora.

Así mismo, de principio a fin,  se están depurando las fechas para verificar si se están leyendo correctamente y se esta obteniendo la respuesta que queremos. Para validar nuestro código se usaron los casos de prueba dados por el profesor c:

Para más detalles del funcionamiento, se recomiendan checar los archivos de cabecera y el archivo .cpp para verificar el funcionamiento de cada clase.
----------------------------------------------------------------------------------------------
*/
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include "Bitacora.h"

DoublyLinkedList leerBitacora(const std::string& filename) {
    DoublyLinkedList lista;
    std::ifstream file(filename);
    std::string linea;

    while (std::getline(file, linea)) {
        std::istringstream iss(linea);
        std::string mes, hora, ip, razon;
        int dia;
        iss >> mes >> dia >> hora >> ip;
        std::getline(iss, razon);
        time_t fechaHora = parseFechaHora(mes, dia, hora);
        lista.append({mes, dia, hora, ip, razon, fechaHora});
    }

    return lista;
}

int main() {
    DoublyLinkedList bitacora = leerBitacora("bitacora.txt"); //Lee nuestro archivo de bitacora

    //std::cout << "Bitácora original:\n"; // Imprime la bitacora original para comprobar que se esa imprimiendo correctamente 
    //bitacora.print();

    bitacora.mergeSort();

    //std::cout << "\nBitácora ordenada:\n"; // Imprime la bitacora ordenada para comprobar que se esa ordenando correctamente
    //bitacora.print();

    // Se guarda nuestra bitacora con las fechas ordenadas en un archivo nuevo
    bitacora.saveToFile("bitacora_ordenada.txt");

    std::string fechaInicio, fechaFin;
    std::cout << "---------------------------------------------------------\n";
    std::cout << "Introduce la fecha de inicio (ejemplo: Jun 01 00:22:36):\n ";
    std::getline(std::cin, fechaInicio);
    std::cout << "\n---------------------------------------------------------\n ";
    std::cout << "\nIntroduce la fecha de fin (ejemplo: Jun 30 23:59:59):\n ";
    std::getline(std::cin, fechaFin);

    std::istringstream issInicio(fechaInicio); //Manda nuestro string a un stream para poder separar por espacios nuestra fecha de inicio 
    std::istringstream issFin(fechaFin); // Separa nuestra fecha de fin por espacios 
    std::string mesInicio, horaInicio, mesFin, horaFin;
    int diaInicio, diaFin;
    issInicio >> mesInicio >> diaInicio >> horaInicio;
    issFin >> mesFin >> diaFin >> horaFin;
    time_t start = parseFechaHora(mesInicio, diaInicio, horaInicio);
    time_t end = parseFechaHora(mesFin, diaFin, horaFin);

    auto resultado = bitacora.searchRange(start, end);

    if (resultado.first.empty()) {
        std::cout << "No se encontraron registros en el rango proporcionado. Por favor introduzca otro rango de fechas para buscar en nuestra bitacora.\n"; // Si no se encuentra ningun registro en el rango de fechas, se le pide al usuario que ingrese una nueva fecha de inicio y fin.
    } else {
        std::ofstream file("resultado_busqueda.txt");
        for (const auto& registro : resultado.first) { 
            std::cout << registro.mes << " " << registro.dia << " " << registro.hora << " "
                      << registro.ip << " " << registro.razon << "\n";
            file << registro.mes << " " << registro.dia << " " << registro.hora << " "
                 << registro.ip << " " << registro.razon << "\n"; //Concatena nuestra fecha, hora, meses, etc. Para generar nuestra fechas que se encuentran en el rango.
        }
        std::cout << "\n---------------------------------------------------------\n";
        std::cout << "\nTotal de registros encontrados:\n" << resultado.second << "\n"; //Imprimimos el total de nuestros registros encontrados en el rango de fechas.
    }
        std::cout << "\n---------------------------------------------------------\n";
    

    return 0;
}
