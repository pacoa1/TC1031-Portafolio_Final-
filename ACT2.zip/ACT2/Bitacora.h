#ifndef BITACORA_H
#define BITACORA_H

#include <string>
#include <vector>
#include <ctime>
#include <utility>  // Para std::pair

// Estructura que representa un registro en la bitácora.
struct Registro {
    std::string mes;
    int dia;
    std::string hora;
    std::string ip;
    std::string razon;
    time_t fechaHora; // Para facilitar el ordenamiento y la búsqueda

    // Sobrecarga del operador < para comparar registros por fecha y hora.
    bool operator<(const Registro& other) const {
        return fechaHora < other.fechaHora;
    }

    // Sobrecarga del operador == para comparar registros por fecha y hora.
    bool operator==(const Registro& other) const {
        return fechaHora == other.fechaHora;
    }
};

// Clase que representa un nodo de la lista doblemente enlazada.
class Nodo {
public:
    Registro data;
    Nodo* next;
    Nodo* prev;
    Nodo(Registro data) : data(data), next(nullptr), prev(nullptr) {}
};

// Clase que representa una lista doblemente enlazada.
class DoublyLinkedList {
public:
    Nodo* head;
    Nodo* tail;

    DoublyLinkedList() : head(nullptr), tail(nullptr) {}

    // Métodos públicos de la lista doblemente enlazada.
    void append(Registro data);
    void mergeSort();
    std::pair<std::vector<Registro>, int> searchRange(time_t start, time_t end);
    void saveToFile(const std::string& filename);
    void print();

private:
    // Métodos privados utilizados internamente.
    Nodo* mergeSort(Nodo* node);
    Nodo* merge(Nodo* left, Nodo* right);
    Nodo* binarySearch(time_t target);
    Nodo* findStartNode(time_t start);
    Nodo* findEndNode(time_t end);
};

// Función que convierte una fecha y hora en formato string a un objeto time_t.
time_t parseFechaHora(const std::string& mes, int dia, const std::string& hora);

#endif
