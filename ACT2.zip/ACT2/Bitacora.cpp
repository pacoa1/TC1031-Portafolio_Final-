// Archivo cpp que nos permite hacer la búsqueda de los datos en la bitácora, tomando como base y seleccionando los parámetros pertinentes.
//-----------------------------------------------------------------------------------------
#include "Bitacora.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <map>

// Mapa que asocia los meses con un índice correspondiente para facilitar la conversión de fechas.
const std::map<std::string, int> mesMap = {
    {"Jan", 0}, {"Feb", 1}, {"Mar", 2}, {"Apr", 3},
    {"May", 4}, {"Jun", 5}, {"Jul", 6}, {"Aug", 7},
    {"Sep", 8}, {"Oct", 9}, {"Nov", 10}, {"Dec", 11}
};

// Método que añade un nuevo registro a la lista doblemente enlazada.
void DoublyLinkedList::append(Registro data) {
    Nodo* newNode = new Nodo(data);
    if (!head) {  // Si la lista está vacía
        head = tail = newNode;
    } else {  // Si la lista no está vacía
        tail->next = newNode;
        newNode->prev = tail;
        tail = newNode;
    }
}

// Función que convierte una fecha y hora en formato string a un objeto time_t para facilitar el ordenamiento y comparación.
time_t parseFechaHora(const std::string& mes, int dia, const std::string& hora) {
    struct tm tm = {};
    tm.tm_year = 120; // 2020 - 1900 (tm_year es el año desde 1900)
    tm.tm_mon = mesMap.at(mes); // Convertir el mes a índice
    tm.tm_mday = dia;
    // Parsear la hora en formato hh:mm:ss
    sscanf(hora.c_str(), "%d:%d:%d", &tm.tm_hour, &tm.tm_min, &tm.tm_sec);
    return mktime(&tm);
}

// Método recursivo que realiza el ordenamiento merge sort en la lista doblemente enlazada.
Nodo* DoublyLinkedList::mergeSort(Nodo* node) {
    if (!node || !node->next) return node; // Caso base: lista vacía o de un solo elemento

    // Encontrar el punto medio de la lista
    Nodo* middle = node;
    Nodo* fast = node->next;

    while (fast && fast->next) {
        middle = middle->next;
        fast = fast->next->next;
    }

    // Dividir la lista en dos mitades
    Nodo* left = node;
    Nodo* right = middle->next;
    middle->next = nullptr;

    // Ordenar recursivamente cada mitad
    left = mergeSort(left);
    right = mergeSort(right);

    // Combinar las dos mitades ordenadas
    return merge(left, right);
}

// Método que combina dos sublistas ordenadas en una sola lista ordenada.
Nodo* DoublyLinkedList::merge(Nodo* left, Nodo* right) {
    Nodo dummy(Registro{"", 0, "", "", "", 0});
    Nodo* tail = &dummy;

    while (left && right) {
        if (left->data < right->data) { // Comparar fechas y horas
            tail->next = left;
            left->prev = tail;
            left = left->next;
        } else {
            tail->next = right;
            right->prev = tail;
            right = right->next;
        }
        tail = tail->next;
    }

    // Agregar los elementos restantes de left o right
    if (left) {
        tail->next = left;
        left->prev = tail;
    } else {
        tail->next = right;
        right->prev = tail;
    }

    return dummy.next;
}

// Método público que inicia el proceso de ordenamiento merge sort.
void DoublyLinkedList::mergeSort() {
    head = mergeSort(head);

    // Actualizar los punteros prev después de ordenar
    Nodo* current = head;
    while (current && current->next) {
        current->next->prev = current;
        current = current->next;
    }
    tail = current;
}

// Método que realiza una búsqueda binaria en la lista doblemente enlazada.
Nodo* DoublyLinkedList::binarySearch(time_t target) {
    Nodo* start = head;
    Nodo* end = nullptr;

    while (start != end) {
        Nodo* middle = start;
        Nodo* fast = start->next;

        while (fast != end && fast->next != end) {
            middle = middle->next;
            fast = fast->next->next;
        }

        if (middle->data.fechaHora == target) {
            return middle;
        } else if (middle->data.fechaHora < target) {
            start = middle->next;
        } else {
            end = middle;
        }
    }

    return nullptr;
}

// Método que encuentra el nodo de inicio en un rango de búsqueda.
Nodo* DoublyLinkedList::findStartNode(time_t start) {
    Nodo* current = head;
    while (current && current->data.fechaHora < start) {
        current = current->next;
    }
    return current;
}

// Método que encuentra el nodo final en un rango de búsqueda.
Nodo* DoublyLinkedList::findEndNode(time_t end) {
    Nodo* current = tail;
    while (current && current->data.fechaHora > end) {
        current = current->prev;
    }
    return current;
}

// Método que busca registros dentro de un rango de fechas y horas.
std::pair<std::vector<Registro>, int> DoublyLinkedList::searchRange(time_t start, time_t end) {
    std::vector<Registro> result;
    int count = 0;

    Nodo* startNode = findStartNode(start);
    Nodo* endNode = findEndNode(end);

    if (!startNode || !endNode || startNode->data.fechaHora > endNode->data.fechaHora) {
        return {result, count};  // No se encontraron registros en el rango
    }

    Nodo* current = startNode;
    while (current && current->data.fechaHora <= end) {
        result.push_back(current->data);
        count++;
        if (current == endNode) break;
        current = current->next;
    }

    return {result, count};
}

// Método que guarda la lista doblemente enlazada en un archivo.
void DoublyLinkedList::saveToFile(const std::string& filename) {
    std::ofstream file(filename);
    Nodo* current = head;
    while (current) {
        file << current->data.mes << " " << current->data.dia << " " << current->data.hora << " "
             << current->data.ip << " " << current->data.razon << "\n";
        current = current->next;
    }
}

// Método que imprime la lista doblemente enlazada en nuestra consola.
void DoublyLinkedList::print() {
    Nodo* current = head;
    while (current) {
        std::cout << current->data.mes << " " << current->data.dia << " " << current->data.hora << " "
                  << current->data.ip << " " << current->data.razon << "\n";
        current = current->next;
    }
}
