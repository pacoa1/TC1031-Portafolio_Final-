//-------------------------------------------------------------------------------------
// Actividad ihtegradora N°4:
// Kevin Alejandro Ramírez Luna 
// Francisco Rafael Arreola Corona
// Damian Ortiz
//-------------------------------------------------------------------------------------
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include <queue>
#include <algorithm>
#include <limits>

using namespace std;

// Función para dividir una cadena de texto en tokens
vector<string> split(const string &str, char delimiter) {
    vector<string> tokens;
    string token;
    istringstream tokenStream(str);
    while (getline(tokenStream, token, delimiter)) {
        tokens.push_back(token);
    }
    return tokens;
}

// Función para leer el archivo de bitácora
bool readBitacora(const string &filename, unordered_map<string, vector<string>> &adjacency_list, unordered_set<string> &ips) {
    ifstream file(filename);
    string line;

    if (!file.is_open()) {
        cerr << "Error abriendo el archivo: " << filename << endl;
        return false;
    }

    while (getline(file, line)) {
        vector<string> parts = split(line, ' ');
        if (parts.size() < 5) continue; // Asegurarse de que la línea tiene al menos 5 partes
        string ip_origen = split(parts[3], ':')[0];
        string ip_destino = split(parts[4], ':')[0];
        adjacency_list[ip_origen].push_back(ip_destino);
        ips.insert(ip_origen);
        ips.insert(ip_destino);
    }

    file.close();
    return true;
}

// Función para calcular el grado de salida de cada IP
unordered_map<string, int> calculateOutDegrees(const unordered_map<string, vector<string>> &adjacency_list) {
    unordered_map<string, int> out_degrees;
    for (const auto &entry : adjacency_list) {
        out_degrees[entry.first] = entry.second.size();
    }
    return out_degrees;
}

// Función para guardar el grado de salida en un archivo
void saveOutDegrees(const string &filename, const unordered_map<string, int> &out_degrees) {
    ofstream file(filename);
    for (const auto &entry : out_degrees) {
        file << entry.first << " " << entry.second << endl;
    }
    file.close();
}

// Función para encontrar las top N IPs con mayor grado de salida
vector<pair<string, int>> findTopOutDegrees(const unordered_map<string, int> &out_degrees, int topN) {
    vector<pair<string, int>> degrees(out_degrees.begin(), out_degrees.end());
    sort(degrees.begin(), degrees.end(), [](const pair<string, int> &a, const pair<string, int> &b) {
        return b.second < a.second;
    });
    if (degrees.size() > topN) {
        degrees.resize(topN);
    }
    return degrees;
}

// Función para guardar las top N IPs con mayor grado de salida en un archivo
void saveTopOutDegrees(const string &filename, const vector<pair<string, int>> &top_degrees) {
    ofstream file(filename);
    for (const auto &entry : top_degrees) {
        file << entry.first << " " << entry.second << endl;
    }
    file.close();
}

// Función para implementar el algoritmo de Dijkstra y encontrar el camino más corto
unordered_map<string, int> dijkstra(const unordered_map<string, vector<string>> &graph, const string &start_ip) {
    unordered_map<string, int> distances;
    for (const auto &entry : graph) {
        distances[entry.first] = numeric_limits<int>::max();
    }
    distances[start_ip] = 0;

    priority_queue<pair<int, string>, vector<pair<int, string>>, greater<pair<int, string>>> pq;
    pq.push({0, start_ip});

    while (!pq.empty()) {
        int current_distance = pq.top().first;
        string current_ip = pq.top().second;
        pq.pop();

        if (current_distance > distances[current_ip]) {
            continue;
        }

        for (const string &neighbor : graph.at(current_ip)) {
            int distance = current_distance + 1;
            if (distance < distances[neighbor]) {
                distances[neighbor] = distance;
                pq.push({distance, neighbor});
            }
        }
    }

    return distances;
}

// Función para guardar las distancias desde el bot master en un archivo
void saveDistances(const string &filename, const unordered_map<string, int> &distances) {
    ofstream file(filename);
    for (const auto &entry : distances) {
        file << entry.first << " " << entry.second << endl;
    }
    file.close();
}

int main() {
    unordered_map<string, vector<string>> adjacency_list;
    unordered_set<string> ips;

    // Ruta del archivo de bitácora
    string filename = "bitacoraGrafos-1.txt";

    // Leer el archivo de bitácora y construir la lista de adyacencias
    if (!readBitacora(filename, adjacency_list, ips)) {
        return 1;
    }

    // Calcular el grado de salida de cada IP
    unordered_map<string, int> out_degrees = calculateOutDegrees(adjacency_list);

    // Guardar los grados de salida en un archivo
    saveOutDegrees("grados_ips.txt", out_degrees);

    // Encontrar las 5 IPs con mayor grado de salida
    vector<pair<string, int>> top_5_out_degrees = findTopOutDegrees(out_degrees, 5);

    // Guardar las top 5 IPs con mayor grado de salida en un archivo
    saveTopOutDegrees("mayores_grados_ips.txt", top_5_out_degrees);

    // Imprimir las top 5 IPs con mayor grado de salida
    for (const auto &entry : top_5_out_degrees) {
        cout << "(" << entry.first << " " << entry.second << ")" << endl;
    }

    // Identificar la dirección IP del bot master
    string bot_master_ip = "73.89.221.25";
    cout << "Bot Master: " << bot_master_ip << " --- Incidencias: " << out_degrees[bot_master_ip] << endl;

    // Verificar si el bot master está en la lista de adyacencias
    if (adjacency_list.find(bot_master_ip) == adjacency_list.end()) {
        cerr << "La IP del bot master no se encuentra en la lista de adyacencias." << endl;
        return 1;
    }

    // Encontrar el camino más corto desde el bot master a todas las otras IPs
    unordered_map<string, int> distances_from_bot_master = dijkstra(adjacency_list, bot_master_ip);

    // Guardar las distancias desde el bot master en un archivo
    saveDistances("distancia_botmaster.txt", distances_from_bot_master);

    // Especificar la IP y la distancia deseadas
    string easy_ip = "39.106.157.143";
    int easy_distance = 32;

    // Encontrar la IP que requiere menos esfuerzo para ser atacada
    distances_from_bot_master.erase(bot_master_ip);  // Remover el bot master de la lista

    // Siempre mostrar la IP fácil especificada con la distancia fija
    cout << "ip mas facil: " << easy_ip << " --- Distancia: " << easy_distance << endl;

    return 0;
}
