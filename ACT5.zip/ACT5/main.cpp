/** 
* Compilacion para debug (banderas):  
*    g++ -std=c++17 -g -o main *.cpp 
* Compilacion para ejecucion:  
*    g++ -std=c++17 -O3 -o main *.cpp 
**/
/**
----------------------------------------------------------------------------------------------
// Kevin Alejandro Ramírez Luna
// Francisco Rafael Arreola Corona
// Damian Reza Ortiz
----------------------------------------------------------------------------------------------
El siguiente código es una implementación de un grafo dirigido utilizando una lista de adyacencia. La clase Graph. Este código es una culminación y extensión de los conceptos vistos en la sección de "Grafos" vistos en la UF.

Por la complejidad del código y del tema de grafos, el código fue dividido en varias funciones para facilitar su comprensión al lector que lo revice; se dividio en archivos de cabecera y .cpp. En cada uno de los archivos se encuentra una documentación de alguna de las partes del código para que sea más facil de entender.
------------------------------------------------------------------------------------------------
**/
#include <iostream>
#include <sstream>
#include "Graph.h"

int main() {
  // Construye un grafo a partir de la consola usando representacion de Lista de adyacencia
  Graph g1("bitacoraGrafos-1.txt");
  //g1.print();  // Imprime el grafo completo
  //g1.gradosIp(); // Manda llamar a gradosIp y por consecuente a dijkstraAlgorithm

  g1.doHashTable(); // se crea la Hash Table a partir del grafo 
  std::string IP;
  std::cout<<"Introduce un numero de Ip: "<<std::endl; 
  getline(std::cin, IP);
  g1.getIPSummary(IP); // se manda a llamar getIPSummary con el grafo g1 y la IP.

  return 0;
}