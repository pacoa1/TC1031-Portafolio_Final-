#ifndef _NODELINKEDLIST_H_
#define _NODELINKEDLIST_H_

template <class T>
class NodeLinkedList {
  public:
    T data;
    NodeLinkedList<T> *next;

    NodeLinkedList();
    NodeLinkedList(T value);
};

// Constructor
template <class T>
NodeLinkedList<T>::NodeLinkedList() : data{}, next{nullptr} {}

// Constructor con parametros 
template <class T>
NodeLinkedList<T>::NodeLinkedList(T value) : data{value}, next{nullptr} {}


#endif // _NODELINKEDLIST_H_
