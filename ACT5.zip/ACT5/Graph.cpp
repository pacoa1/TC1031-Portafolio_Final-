#include "Graph.h"

// definicion de los metodos

// Constructor: recibe como parametro un string con el nombre del archivo a abrir 
Graph::Graph(std::string input) { loadGraphList(input); }

// Destructor: vacia la lista de adyacencia
Graph::~Graph() { adjList.clear(); }

// Recibe como parametro el nombre del archivo a abrir, lo carga y lee cada ip y la almacena en una lista de adyacencia
void Graph::loadGraphList(std::string input) {
  std::string line, ipOrigen, ipDestino, ip; 
  int peso;
  int i = 0;         // indice de lectura que se recorre para leer el archivo completo
  std::ifstream file(input);
  while (std::getline(file, line)) { // comenzamos a leer cada linea
    if (i == 0) {
      std::istringstream NODOS(line); // leemos datos de una cadena de texto con istringstream
      NODOS >> numNodes >> numEdges; // leemos y extraemos el numero de nodos y aristas

      // Reservar memoria para renglones de la lista de adyacencia
      // Nodos son uno basados (renglon 0 no sera usado)
      adjList.resize(numNodes + 1);

      // Declarar un lista vacia para cada renglon y se almacena en el vector
      for (int k = 1; k <= numNodes; k++) {
        LinkedList<std::pair<int, int>> tmpList;
        adjList[k] = tmpList;
      }
      i++;
      continue;
    }
    if (i <= numNodes &&
        i != 0) { // condicion de paro para almacenar los nodos en listaIpOrden,
                  // numNodes es la fila donde terminan las IPs en el .txt
      std::istringstream NODOS(line);
      std::getline(NODOS, ip);
      ipOrden orden(ip, i);

      // meter orden en un map STL
      mapIpOrden.insert({orden.getIpNum(), orden});
      listaIpOrden.push_back(orden);
      i++;
    } else { // condicion para que comience a leer las aristas
        std::istringstream NODOS(line);
        std::string palabra; // Variable temporal para almacenar las palabras que
                           // se van extrayendo de cada linea de la bitacora.

        for (int j = 0; j < 3; j++) {
          NODOS >> palabra; // ignoramos las primeras 3 palabras, fecha y hora
        }

        // Almacenamos la primera IP, IP de origen
        NODOS >> palabra;
        ipOrigen = palabra.substr(0, palabra.find(':')); 
                                      // 0 representa el primer caracter de la cadena y va a
                                      // leer el dato hasta encontrar el caracter ':'

        // Ignoramos el puerto
        std::string puerto = palabra.substr(palabra.find(':') + 1, palabra.length()); 
                                      // el caracter comenzara despues de encontrar ':' e
                                      // ignorara la palabra de longitud del puerto

        // Almacenamos la segunda IP, IP de destino
        NODOS >> palabra;
        ipDestino = palabra.substr(0, palabra.find(':'));

        // Almacenamos el peso
        NODOS >> peso;

        // Lectura de las aristas del grafo
        ipOrden ip1(ipOrigen, 0);
        ipOrden ip2(ipDestino, 0);
        int nodoU = -1;
        int nodoV = -1;
        std::map<unsigned int, ipOrden>::iterator it1;
        std::map<unsigned int, ipOrden>::iterator it2;
        it1 = mapIpOrden.find(ip1.getIpNum());
        if (it1 != mapIpOrden.end())
          nodoU = it1->second.getOrden();
        it2 = mapIpOrden.find(ip2.getIpNum());
        if (it2 != mapIpOrden.end())
          nodoV = it2->second.getOrden();
        if (nodoU != -1 && nodoV != -1) {
          // grafo dirigido, agregar arista (u,v) y el peso
          adjList[nodoU].addLast(std::make_pair(nodoV, peso));
          it1->second.addGrado();
          it2->second.addGradoIn();
          listaIpOrden[it1->second.getOrden()].addGrado();
          listaIpOrden[it2->second.getOrden()].addGradoIn();
          //std::cout << nodoU << " " << nodoV << std::endl;
        }
        i++;
      }
  
    // condicion de paro para dejar de leer las aristas en la bitacora
    if (i > numNodes + numEdges) {
      break;
    }
  }
}

// Complejidad O(n+m)
// Imprime la lista de adyacencia
void Graph::printAdjList() {
  std::cout << "numNode: " << numNodes << std::endl;
  std::cout << "numEdges: " << numEdges << std::endl;
  std::cout << "--ADJACENCY LIST--" << std::endl;
  for (int nodeU = 1; nodeU <= numNodes; nodeU++) {
    std::cout << "vertex " << nodeU << ": ";
    NodeLinkedList<std::pair<int, int>> *ptr = adjList[nodeU].getHead();
    while (ptr != nullptr) {
      std::pair<int, int> par = ptr->data;
      std::cout << "{" << par.first << "," << par.second << "} ";
      ptr = ptr->next;
    }
    std::cout << std::endl;
  }
}

// Complejidad O(n+m)
// Manda llamar al metodo printAdjList()
void Graph::print() { printAdjList(); }

// Complejidad O(E * logV)
// El metodo calcula y almacena los grados de las IPs en un archivo
// "grados_ips.txt", selecciona las 5 IPs con los grados más altos y las
// almacena en otro archivo "mayores_grados_ips.txt", guarda la IP con el grado
// más alto en la variable bootMaster y luego manda llamar al método
// dijkstraAlgorithm()
void Graph::gradosIp() {
  std::priority_queue<std::pair<int, ipOrden>> pq;
  std::map<unsigned int, ipOrden>::iterator it;
  // abre el archivo en modo escritura
  std::ofstream outFile("grados_ips.txt");
  // Verifica si el archivo se abrió correctamente
  if (!outFile) {
    std::cout << "Error al abrir el archivo." << std::endl;
    return;
  }

  // almacenamos los grados con cada ip en "grados_ips.txt"
  for (it = mapIpOrden.begin(); it != mapIpOrden.end(); it++) {
    outFile << "IP: " << it->second.getIpStr()
            << ", Grado Salida: " << it->second.getGrado() << std::endl;
    // meter en un max heap
    pq.push({it->second.getGrado(), it->second});
  }
  // Cierra el archivo
  outFile.close();

  // abre el archivo en modo escritura
  std::ofstream outFilee("mayores_grados_ips.txt");

  // Verifica si el archivo se abrió correctamente
  if (!outFilee) {
    std::cout << "Error al abrir el archivo." << std::endl;
    return;
  }

  int i = 0;
  // almacenamos los grados con cada ip en "mayores_grados_ips.txt"
  outFilee << "5 IPs con mayor grado de salida: " << std::endl;
  while (!pq.empty() && i < 5) {
    ipOrden obj = pq.top().second;
    outFilee << "IP: " << obj.getIpStr() << ", Grado: " << obj.getGrado()
             << std::endl;
    if (i == 0) {
      bootMaster = pq.top().second;
      std::cout << std::endl;
      std::cout << "Boot Master se encuentra en la IP: "
                << bootMaster.getIpStr() << ", Grado: " << bootMaster.getGrado()
                << " numNode: " << bootMaster.getOrden() << std::endl
                << std::endl;
    }
    pq.pop();
    i++;
  }
  // Cierra el archivo
  outFilee.close();
  dijkstraAlgorithm(bootMaster.getOrden());
}

// Complejidad O(E * logV)
// Algoritmo que permite conocer las distancias respecto a un nodo, en este caso
// Boot Master el metodo calcula las distancias más cortas entre el nodo de
// origen boot Master y todos los demás nodos del grafo utilizando el algoritmo
// de Dijkstra, y guarda los resultados en un archivo. Asimismo identifica la IP
// con la menor distancia que no sea 0 y la imprime en la consola.
void Graph::dijkstraAlgorithm(int v) {
  // Crear una priority queue del STL de C++
  // https://www.geeksforgeeks.org/implement-min-heap-using-stl/
  std::priority_queue<std::pair<int, int>, std::vector<std::pair<int, int>>,
                      std::greater<std::pair<int, int>>>
      pq;

  // vector de distancias con el resultado del algoritmo
  std::vector<int> dist(numNodes + 1, INF);
  // Insertar el nodo de origen v en la priority queue -- pares (dist, vertice)
  pq.push(std::make_pair(0, v)); // la distancia de v a v es cero
  dist[v] = 0;
  // Mientras el priority queue no este vacio
  while (!pq.empty()) {
    // Extraer un vertice de el priority queue
    int nodeU = pq.top().second; // pares (dist, vertice)
    pq.pop();
    // Obtener los vecions del vertice nodeU
    NodeLinkedList<std::pair<int, int>> *ptr = adjList[nodeU].getHead();
    while (ptr != nullptr) {
      std::pair<int, int> par = ptr->data;
      int nodeV = par.first; 
      int peso = par.second; // peso de la arista (nodoU,nodeV)
      if (dist[nodeV] > dist[nodeU] + peso) {
        // Actualizar la distancia (mas corta) de nodeV
        dist[nodeV] = dist[nodeU] + peso;
        pq.push(std::make_pair(dist[nodeV], nodeV));
      }
      ptr = ptr->next;
    }
  }

  // abre el archivo en modo escritura
  std::ofstream outFile("distancia_bootmaster.txt");

  // Verifica si el archivo se abrió correctamente
  if (!outFile) {
    std::cout << "Error al abrir el archivo." << std::endl;
    return;
  }

  // Imprimir las distancias mas cortas entre v y todos los nodos del grafo
  outFile << "Vertice\tDistancia desde v" << std::endl;
  int minDistancia = INF;
  std::string ipMinima;

  for (int i = 1; i <= numNodes; i++) {
    if (dist[i] != INF) {
      outFile << listaIpOrden[i - 1].getIpStr() << ", \t" << dist[i]
              << std::endl;
      // if (dist[i] > minDistancia) {
      if (dist[i] < minDistancia && dist[i] != 0) {
        minDistancia = dist[i];
        ipMinima = listaIpOrden[i - 1].getIpStr();
      }
    } else {
      std::cout << listaIpOrden[i - 1].getIpStr() << "\tINF" << std::endl;
    }
  }
  // Cierra el archivo
  outFile.close();

  if (minDistancia != INF && minDistancia > 0)
    std::cout << "Ip que menos esfuerzo requiere para atacar: " << ipMinima
              << ", Distancia: " << minDistancia << std::endl;
}

// Complejidad O(numNodes)
// Crea la tabla Hash con direccion Abierta (hashing cerrado) con Muestreo
// Cuadratico para manejo de colisiones
void Graph::doHashTable() {
  std::cout << "Se crea la Hash Table" << std::endl;
  std::cout << "mapa size " << mapIpOrden.size() << std::endl;

  // numNodes 13370 para sacar el maxSize buscamos el numero primo mas cercano
  hashT.setMaxSize(13679);
  std::map<unsigned int, ipOrden>::iterator it;
  for (it = mapIpOrden.begin(); it != mapIpOrden.end(); ++it) {
    hashT.add(it->first, it->second);
  }
  /* Opcion 2 del for anterior 
  for (int u = 1; u <= numNodes; u++) {
    hashT.add(listaIpOrden[u].getIpNum(), listaIpOrden[u]);
  }
  */
  
  // Se imprime el numero de colisiones
  std::cout << "Colisiones Totales: " << hashT.getColisiones() << std::endl;
  std::cout << std::endl;
}

// MaxSize 13371 = Colisiones 235376
// MaxSize 13383 = Colisiones 78754
// MaxSize 13397 = Colisiones 68482
// MaxSize 13419 = Colisiones 63915
// MaxSize 13479 = Colisiones 49206
// MaxSize 13497 = Colisiones 48959
// MaxSize 13679 = Colisiones 36365

// Complejidad  O(n log n)
// Recibe como entrada una IP que fue solicitada al usuario en pantalla, y la
// cual se validó para garantizar que existe en la bitácora. 

void Graph::getIPSummary(std::string IP) {
  ipOrden tmpIP(IP, 0);
  ipOrden result = hashT.find(tmpIP.getIpNum());
  // El resumen completo de la información relativa a la IP recibida (valor de la tabla hash)
  std::cout << std::endl;
  std::cout << "Ip: " << result.getIpStr() << std::endl;
  std::cout << "La IP se encuentra en el indice: " << result.getOrden()
            << std::endl;
  std::cout << "Numero de direcciones accesadas desde dicha IP: "
            << result.getGrado() << std::endl;
  std::cout << "Numero de direcciones que intentaron acceder a dicha IP: "
            << result.getGradoIn() << std::endl;
  std::cout << std::endl;

  // La lista completa de direcciones accesadas desde la IP recibida, ordenadas de forma descendente
  std::cout << std::endl;
  std::cout << "IPs que intentaron ingresar a la IP: " << std::endl;
  int nodo = result.getOrden();

  std::vector<ipOrden> resultA;
  for (int j = 0; j < adjList[nodo].getNumElements(); j++) {
    std::pair<int, int> arista = adjList[nodo].getData(j);
    resultA.push_back(listaIpOrden[arista.first]);
  }

  std::sort(resultA.begin(), resultA.end());
  std::reverse(resultA.begin(), resultA.end());
  for (int j = 0; j < resultA.size(); j++) {
    std::cout << resultA[j].getIpStr() << std::endl;
  }
  
}
