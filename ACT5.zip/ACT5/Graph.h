// Esta clase permite representar grafos dirigidos 
#ifndef _GRAPH_H_
#define _GRAPH_H_

#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <iostream>
#include <sstream>
#include <map>
#include <utility>
#include <queue>
#include "HashTable.h"
#include "LinkedList.h"
#include "ipOrden.h"


#define INF 0x3f3f3f3f

// Clase Graph
class Graph {
  private:
    int numNodes;
    int numEdges;
    ipOrden bootMaster;
    std::vector<ipOrden> listaIpOrden;
    std::map<unsigned int, ipOrden> mapIpOrden;
    std::vector<LinkedList<std::pair<int, int>>> adjList;
    void loadGraphList(std::string input);
    void printAdjList(); // imprime la lista de adyacencia
    HashTable<unsigned int, ipOrden> hashT; // Hash table <K=ipNum, T=ipOrden>

  public:
    Graph(std::string input);
    ~Graph();
    void print();
    void gradosIp(); // Genera el archivo "grados_ips.txt"
    void mayorGrado(); // Genera el archivo "mayores_grados_ips.txt"
    void dijkstraAlgorithm(int v); // Genera el archivo "distancia_bootmaster.txt"
    void doHashTable();
    void getIPSummary(std::string IP);
    bool compareDesc(const ipOrden& a, const ipOrden& b);

};

#endif // __GRAPH_H_