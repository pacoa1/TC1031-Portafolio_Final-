#ifndef REGISTRO_H
#define REGISTRO_H

#include <string>

class Registro {
private:
    std::string lineaOriginal;
    std::string ip;
public:
    Registro(const std::string& linea);
    std::string getIP() const;
    std::string getLineaOriginal() const;
};

#endif // REGISTRO_H