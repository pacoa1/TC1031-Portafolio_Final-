#ifndef IPACCESO_H
#define IPACCESO_H

#include <string>

class IPAcceso {
public:
    std::string ip;
    int accesos;

    IPAcceso(const std::string& ip, int accesos);
    bool operator<(const IPAcceso& otro) const;
};

#endif // IPACCESO_H