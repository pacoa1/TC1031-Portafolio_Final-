#include "IPAcceso.h"

IPAcceso::IPAcceso(const std::string& ip, int accesos) : ip(ip), accesos(accesos) {}

bool IPAcceso::operator<(const IPAcceso& otro) const {
    return accesos < otro.accesos;
}