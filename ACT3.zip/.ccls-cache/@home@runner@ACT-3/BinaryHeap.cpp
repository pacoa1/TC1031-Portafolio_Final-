#include "BinaryHeap.h"
#include <stdexcept>

void BinaryHeap::heapifyDown(int index) {
    int left = 2 * index + 1;
    int right = 2 * index + 2;
    int largest = index;

    if (left < heap.size() && heap[left] < heap[largest]) {
        largest = left;
    }
    if (right < heap.size() && heap[right] < heap[largest]) {
        largest = right;
    }
    if (largest != index) {
        std::swap(heap[index], heap[largest]);
        heapifyDown(largest);
    }
}

void BinaryHeap::heapifyUp(int index) {
    if (index && heap[(index - 1) / 2] < heap[index]) {
        std::swap(heap[index], heap[(index - 1) / 2]);
        heapifyUp((index - 1) / 2);
    }
}

void BinaryHeap::insert(const IPAcceso& elemento) {
    heap.push_back(elemento);
    heapifyUp(heap.size() - 1);
}

IPAcceso BinaryHeap::extractMax() {
    if (heap.empty()) {
        throw std::runtime_error("Heap is empty");
    }
    IPAcceso root = heap.front();
    heap[0] = heap.back();
    heap.pop_back();
    heapifyDown(0);
    return root;
}

bool BinaryHeap::isEmpty() const {
    return heap.empty();
}