#include "Bitacora.h"
#include <fstream>
#include <sstream>
#include <algorithm>

void Bitacora::cargarDesdeArchivo(const std::string& nombreArchivo) {
    std::ifstream archivo(nombreArchivo);
    std::string linea;

    while (std::getline(archivo, linea)) {
        registros.push_back(Registro(linea));
    }
}

const std::vector<Registro>& Bitacora::getRegistros() const {
    return registros;
}

void Bitacora::ordenarPorIP() {
    std::sort(registros.begin(), registros.end(), [](const Registro& a, const Registro& b) {
        return a.getIP() < b.getIP();
    });
}

void Bitacora::guardarOrdenado(const std::string& nombreArchivo) const {
    std::ofstream archivo(nombreArchivo);

    for (const auto& registro : registros) {
        archivo << registro.getLineaOriginal() << std::endl;
    }
}