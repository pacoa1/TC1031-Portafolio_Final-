#ifndef BITACORA_H
#define BITACORA_H

#include <vector>
#include <string>
#include "Registro.h"

class Bitacora {
private:
    std::vector<Registro> registros;
public:
    void cargarDesdeArchivo(const std::string& nombreArchivo);
    const std::vector<Registro>& getRegistros() const;
    void ordenarPorIP();
    void guardarOrdenado(const std::string& nombreArchivo) const;
};

#endif // BITACORA_H