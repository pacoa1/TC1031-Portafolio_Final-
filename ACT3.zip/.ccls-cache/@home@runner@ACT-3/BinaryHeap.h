#ifndef BINARYHEAP_H
#define BINARYHEAP_H

#include <vector>
#include "IPAcceso.h"

class BinaryHeap {
private:
    std::vector<IPAcceso> heap;

    void heapifyDown(int index);
    void heapifyUp(int index);

public:
    void insert(const IPAcceso& elemento);
    IPAcceso extractMax();
    bool isEmpty() const;
};

#endif // BINARYHEAP_H