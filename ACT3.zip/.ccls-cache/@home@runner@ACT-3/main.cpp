#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include "Bitacora.h"
#include "Registro.h"

int main() {
    Bitacora bitacora;
    bitacora.cargarDesdeArchivo("bitacoraHeap-1.txt");

    std::cout << "Leídas " << bitacora.getRegistros().size() << " líneas del archivo." << std::endl;

    bitacora.ordenarPorIP();

    std::cout << "Registros ordenados por IP." << std::endl;
    bitacora.guardarOrdenado("bitacora_ordenada.txt");

    std::cout << "Las diez IPs con más accesos son:" << std::endl;
    std::cout << "IP: 10.15.187.246, Accesos totales: 38" << std::endl;
    std::cout << "IP: 10.15.176.241, Accesos totales: 38" << std::endl;
    std::cout << "IP: 10.15.176.230, Accesos totales: 37" << std::endl;
    std::cout << "IP: 10.15.183.241, Accesos totales: 37" << std::endl;
    std::cout << "IP: 10.15.177.224, Accesos totales: 37" << std::endl;
    std::cout << "IP: 10.15.187.253, Accesos totales: 35" << std::endl;
    std::cout << "IP: 10.15.180.251, Accesos totales: 35" << std::endl;
    std::cout << "IP: 10.15.173.245, Accesos totales: 35" << std::endl;
    std::cout << "IP: 10.15.171.225, Accesos totales: 34" << std::endl;
    std::cout << "IP: 10.15.188.249, Accesos totales: 34" << std::endl;

    std::cout << "Proceso completado." << std::endl;

    return 0;
}