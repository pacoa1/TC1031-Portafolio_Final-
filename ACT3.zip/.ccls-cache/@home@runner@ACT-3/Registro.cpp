#include "Registro.h"
#include <sstream>

Registro::Registro(const std::string& linea) : lineaOriginal(linea) {
    std::istringstream stream(linea);
    std::string mes, dia, hora, ip;
    stream >> mes >> dia >> hora >> ip;
    this->ip = ip;
}

std::string Registro::getIP() const {
    return ip;
}

std::string Registro::getLineaOriginal() const {
    return lineaOriginal;
}