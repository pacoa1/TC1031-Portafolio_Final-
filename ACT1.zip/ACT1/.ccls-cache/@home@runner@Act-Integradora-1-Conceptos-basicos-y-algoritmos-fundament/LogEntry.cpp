#include "LogEntry.h"

LogEntry::LogEntry(const std::string& ip, const std::string& date, int status, const std::string& user)
    : ip(ip), status(status), user(user) {
        std::istringstream ss(date);
        ss >> std::get_time(&date, "%b %d %H:%M:%S");
}

std::ostream& operator<<(std::ostream& os, const LogEntry& entry) {
    std::stringstream ss;
    ss << std::put_time(&entry.date, "%b %d %H:%M:%S");
    os << entry.ip << " " << ss.str() << " " << entry.status << " " << entry.user;
    return os;
}