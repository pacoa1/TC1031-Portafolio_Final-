#ifndef LOG_ENTRY_H
#define LOG_ENTRY_H

#include <string>
#include <vector>
#include <algorithm>
#include <sstream>
#include <ctime>

class LogEntry {
private:
    std::string ip;
    std::tm date;
    int status;
    std::string user;

public:
    LogEntry(const std::string& ip, const std::string& date, int status, const std::string& user);

    bool operator<(const LogEntry& other) const {
        return std::memcmp(&date, &other.date, sizeof(std::tm)) < 0;
    }

    friend std::ostream& operator<<(std::ostream& os, const LogEntry& entry);
};

std::vector<LogEntry> read_log_entries(const std::string& filename);
std::pair<std::vector<LogEntry>::iterator, std::vector<LogEntry>::iterator> search_log_entries(std::vector<LogEntry>& log_entries, const std::tm& start_date, const std::tm& end_date);
void sort_log_entries(std::vector<LogEntry>& log_entries, const std::string& algorithm);
void bubble_sort(std::vector<LogEntry>& log_entries);

#endif // LOG_ENTRY_H