// Kevin Alejandro Ramírez Luna
// Francisco Rafael Arreola Corona
// Damián Reza
// Código usado para la demostración y uso de los ordenamientos lienales

// Para correr el código se debe especificar lo siguiente:
// g++ -std=c++11 -o main main.cpp
//---------------------------------------------------------------------

// Definición de liberias y paquetes a utilizar 
// Incluye las definiciones anteriores de Record, parseDateTime, formatDateTime, readLogFile, y writeRecordsToFile aquí
// Código usado para la demostración y uso de los ordenamientos lineales

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>
#include <ctime>

struct Record {
    std::tm datetime; // Estructura para almacenar fecha y hora
    std::string event; // Campo para almacenar el evento o mensaje
};

// Función para analizar fecha y hora desde cadenas de texto
std::tm parseDateTime(const std::string& dateTime) {
    std::tm tm = {};
    std::istringstream dateTimeStream(dateTime);

    std::string month;
    int day, hour, minute, second;
    char sep;

    // Leer mes y día
    dateTimeStream >> month >> day;

    // Convertir mes a número
    const char* months[] = {"Jan", "Feb", "Mar", "Apr", "May", "Jun",
                            "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
    for (int i = 0; i < 12; i++) {
        if (month == months[i]) {
            tm.tm_mon = i;
            break;
        }
    }
    tm.tm_mday = day;

    // Leer hora, minuto y segundo
    dateTimeStream >> hour >> sep >> minute >> sep >> second;
    tm.tm_hour = hour;
    tm.tm_min = minute;
    tm.tm_sec = second;

    return tm;
}

// Función para formatear fecha y hora
std::string formatDateTime(const std::tm& tm) {
    char buffer[20]; // Ajusta el tamaño según sea necesario
    std::strftime(buffer, sizeof(buffer), "%b %d %H:%M:%S", &tm);
    return std::string(buffer);
}

// Función para leer el archivo de bitácora y almacenar registros
void readLogFile(const std::string &filename, std::vector<Record> &records) {
    std::ifstream file(filename);
    std::string line;

    while (std::getline(file, line)) {
        std::istringstream stream(line);
        Record record;

        // Leer fecha y hora
        std::string dateTime;
        std::getline(stream, dateTime, '\t');  // Modifica para separar por tabulación u otro delimitador

        // Analizar fecha y hora utilizando parseDateTime
        record.datetime = parseDateTime(dateTime);

        // Leer el evento
        std::getline(stream, record.event);
        records.push_back(record);
    }
}

// Función para escribir registros en un archivo
void writeRecordsToFile(const std::string &filename, const std::vector<Record> &records) {
    std::ofstream file(filename);

    for (const Record &record : records) {
        file << formatDateTime(record.datetime) << " " << record.event << std::endl;
    }
}

// Función para comparar fechas de dos registros
bool compareDates(const Record &a, const Record &b) {
    // Compara las fechas utilizando la función `difftime` de `std::difftime`
    return std::difftime(std::mktime(const_cast<std::tm*>(&a.datetime)),
                         std::mktime(const_cast<std::tm*>(&b.datetime))) < 0;
}

// Función para fusionar dos mitades ordenadas
void merge(std::vector<Record> &records, int left, int mid, int right) {
    // Crear arreglos temporales para las mitades
    std::vector<Record> leftArray(records.begin() + left, records.begin() + mid + 1);
    std::vector<Record> rightArray(records.begin() + mid + 1, records.begin() + right + 1);

    // Índices de iteración para las mitades
    int leftIndex = 0;
    int rightIndex = 0;
    int mergeIndex = left;

    // Fusionar las dos mitades ordenadas
    while (leftIndex < leftArray.size() && rightIndex < rightArray.size()) {
        if (compareDates(leftArray[leftIndex], rightArray[rightIndex])) {
            records[mergeIndex] = leftArray[leftIndex];
            leftIndex++;
        } else {
            records[mergeIndex] = rightArray[rightIndex];
            rightIndex++;
        }
        mergeIndex++;
    }

    // Copiar los registros restantes de la mitad izquierda
    while (leftIndex < leftArray.size()) {
        records[mergeIndex] = leftArray[leftIndex];
        leftIndex++;
        mergeIndex++;
    }

    // Copiar los registros restantes de la mitad derecha
    while (rightIndex < rightArray.size()) {
        records[mergeIndex] = rightArray[rightIndex];
        rightIndex++;
        mergeIndex++;
    }
}

// Función de ordenamiento Merge Sort
void mergeSort(std::vector<Record> &records, int left, int right) {
    if (left < right) {
        // Encontrar el punto medio
        int mid = left + (right - left) / 2;

        // Ordenar las dos mitades recursivamente
        mergeSort(records, left, mid);
        mergeSort(records, mid + 1, right);

        // Fusionar las mitades ordenadas
        merge(records, left, mid, right);
    }
}


// Función para realizar búsqueda binaria de la fecha inicial y final
int binarySearch(const std::vector<Record> &records, const std::tm &target) {
    int left = 0;
    int right = records.size() - 1;
    while (left <= right) {
        int mid = left + (right - left) / 2;
        double diff = std::difftime(std::mktime(const_cast<std::tm*>(&records[mid].datetime)), std::mktime(const_cast<std::tm*>(&target)));
        if (diff == 0) {
            return mid; // Encontramos el registro
        } else if (diff < 0) {
            left = mid + 1;
        } else {
            right = mid - 1;
        }
    }
    return -1; // No se encontró
}

// Función principal
int main() {
    // Nombre del archivo de bitácora
    std::string logFilename = "bitacora.txt";

    // Leer registros de bitácora
    std::vector<Record> records;
    readLogFile(logFilename, records);

    // Ordenar registros usando Merge Sort
    mergeSort(records, 0, records.size() - 1);

    // Guardar registros ordenados en un archivo
    std::string sortedFilename = "bitacora_ordenada.txt";
    writeRecordsToFile(sortedFilename, records);

    // Solicitar fechas de inicio y fin de búsqueda
    std::string startDateStr, endDateStr;
    std::cout << "Ingrese la fecha de inicio (formato: Jun 01 00:22:36): ";
    std::getline(std::cin, startDateStr);
    std::cout << "Ingrese la fecha de fin (formato: Jun 01 00:22:36): ";
    std::getline(std::cin, endDateStr);

    // Analizar las fechas
    std::tm startDate = parseDateTime(startDateStr);
    std::tm endDate = parseDateTime(endDateStr);

    // Buscar índices de las fechas
    int startIndex = binarySearch(records, startDate);
    int endIndex = binarySearch(records, endDate);

    // Verificar si las fechas se encuentran en los registros
    if (startIndex == -1) {
        std::cout << "La fecha de inicio no se encuentra en los registros." << std::endl;
        return 1;
    }
    if (endIndex == -1) {
        std::cout << "La fecha de fin no se encuentra en los registros." << std::endl;
        return 1;
    }

    // Guardar resultados de la búsqueda en un archivo
    std::string searchResultFilename = "resultado_busqueda.txt";
    std::ofstream searchResultFile(searchResultFilename);

    // Mostrar y guardar resultados de la búsqueda
    for (int i = startIndex; i <= endIndex; i++) {
        const Record &record = records[i];
        std::cout << formatDateTime(record.datetime) << " " << record.event << std::endl;
        searchResultFile << formatDateTime(record.datetime) << " " << record.event << std::endl;
    }

    // Cerrar archivo de resultados de búsqueda
    searchResultFile.close();

    return 0;
}