#ifndef _HASH_TABLE_H
#define _HASH_TABLE_H

#include <iostream>
#include <vector>
#include <stdexcept>
#include "HashNode.h"

template <class K, class T>
class HashTable {
  private:
    std::vector<HashNode<K, T>> table;
    int numElements;
    // Preferible usar un numero primo
    // https://numerosprimos.org/numeros-primos-de-1-a-100000/
    int maxSize;
    int colisiones;

  public:
    HashTable();
    HashTable(int selectedMaxSize);
    void setMaxSize(int selectedMaxSize);
    // Funcion hash
    int getHashIndex(K key);
    int getNumElements();
    void print();
    void add(K keyValue, T dataValue);
    T find(K keyValue);
    T getDataAt(int index);
    void remove(K keyValue);
    int getColisiones();
};

// Constructor
template <class K, class T>
HashTable<K, T>::HashTable() {
  maxSize = 0;
  numElements = 0;
  colisiones = 0;
  table = std::vector<HashNode<K,T>>(maxSize);
}

// Constructor con parametros 
template <class K, class T>
HashTable<K, T>::HashTable(int selectedMaxSize) {
  maxSize = selectedMaxSize;
  numElements = 0;
  colisiones = 0;
  table = std::vector<HashNode<K,T>>(maxSize);
}

// Complejidad O(maxSize)
// Se utiliza para establecer el tamaño maximo de la tabla Hash 
template <class K, class T>
void HashTable<K, T>::setMaxSize(int selectedMaxSize) {
  maxSize = selectedMaxSize;
  numElements = 0;
  colisiones = 0;
  table = std::vector<HashNode<K,T>>(maxSize);
}

// Complejidad O(1)
// Regresa y calcula el indice Hash para una clave especifica
template<class K, class T>
int HashTable<K, T>::getHashIndex(K keyVal) {
  // metodo de residuales (llave mod maxSize)
  return keyVal % maxSize;
}

// Complejidad O(1)
// Regresa el numero de elementos 
template<class K, class T>
int HashTable<K, T>::getNumElements() {
  return numElements;
}

// Complejidad O(maxSize)
// Imprime en pantalla los elementos de la tabla hash
template<class K, class T>
void HashTable<K,T>::print() {
  std::cout << "Content of the hash table: " << std::endl;
  for (int i = 0; i < maxSize; i++) {
    // status:  0 empty, 1 used, 2 deleted
    if (table[i].getStatus() == 1) // Cell is used
      std::cout << "Cell: " << i << " Key: " << table[i].getKey() << ", Value: " << table[i].getData() << ", Overflow.size: " << table[i].getOverflowSize() << std::endl;
  }
}

// Complejidad O(n)
// Permite agregar un nuevo elemento compuesto por keyValue y value a la tabla Hash
template<class K, class T>
void HashTable<K,T>::add(K keyVal, T value) {
  if (numElements == maxSize) {
    throw std::out_of_range("Hash Table is full");
  }
  //if (find(keyVal) != -1) {
    //throw std::out_of_range("Element is already in the Hash Table");
  //}
  // Compute the index of the table using a key and a hash function
  int hashVal = getHashIndex(keyVal); 
  HashNode<K, T> node = table[hashVal];
  // status:  0 empty, 1 used, 2 deleted
  if (node.getStatus() != 1) { // Cell is free
    node.setKey(keyVal);
    node.setData(value);
    table[hashVal] = node;
  }
  else { // Cell is already taken
    // Find next free space using quadratic probing
    // https://www.geeksforgeeks.org/quadratic-probing-in-hashing/
    int i = 1;
    int currentHashVal = getHashIndex(hashVal + i * i);
    HashNode<K, T> currentNode = table[currentHashVal];
    while (currentNode.getStatus() == 1) { // Cell is used
      i++;
      currentHashVal = getHashIndex(hashVal + i * i);
      currentNode = table[currentHashVal];
      colisiones ++;
    }
    // A free cell was found
    currentNode.setKey(keyVal);
    currentNode.setData(value);
    node.addToOverflow(currentHashVal);
    table[currentHashVal] = currentNode;
    table[hashVal] = node;
  }
  numElements++;
}

// Complejidad O(n)
// Busca y regresa un valor en la tabla hash almacenado en una clave especifica
template<class K, class T>
T HashTable<K,T>::find(K keyVal) {
  T result = {};
  int hashVal = getHashIndex(keyVal); 
  HashNode<K, T> node = table[hashVal];
  // status:  0 empty, 1 used, 2 deleted
  if (node.getStatus() == 1) { // Cell is used
    if (node.getKey() == keyVal) {
      //return hashVal;
      return node.getData();
    }
    for (int i = 0; i < (int)node.getOverflowSize(); i++) {
      int overflowIndex = node.getOverflowAt(i);
      if (table[overflowIndex].getKey() == keyVal) {
        //return overflowIndex;
        return table[overflowIndex].getData();
      }
    }
    return result;
  }
  return result;
}

// Complejidad O(1)
// Regresa los datos almacenados en un nodo de la tabla hash en una posicion especifica 
template<class K, class T>
T HashTable<K,T>::getDataAt(int index) {
  return table[index].getData();
}

// Complejidad O(n)
// Elimina un elemento de la tabla Hash segun su clave 
template<class K, class T>
void HashTable<K,T>::remove(K keyVal) {
  int pos, hashVal;
  pos = find(keyVal);
  if (pos == -1) {
    throw std::invalid_argument("Element does not exist in hash table");
  }
  hashVal = getHashIndex(keyVal);
  if (pos != hashVal) { // collision element 
    HashNode<K, T> node = table[hashVal];
    node.removeFromOverflow(pos);
    table[hashVal] = node;
  }
  table[pos].clearData(); 
  numElements--;
}

// Complejidad O(1)
// Regresa el numero de Colisiones que se generaron
template <class K, class T>
int HashTable<K,T>::getColisiones(){
  return colisiones;
}

#endif // _HASH_TABLE_H
