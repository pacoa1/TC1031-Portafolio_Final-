#ifndef _IPORDEN_H
#define _IPORDEN_H

#include <iostream>
#include <string>
#include <cmath>
#include <vector>

class ipOrden{
private:
  unsigned int ipnum;
  std::string ip;
  int orden; 
  int grado;
  int gradoIn;

public:
  //constructor
  ipOrden();
  ipOrden(std::string _ip, int _orden);

  unsigned int getIpNum(); // retorna el valor de ipNum
  int getOrden();
  void setGrado(int _grado); // set de grado
  void addGrado();
  int getGrado();
  std::string getIpStr();
  void setGradoIn(int _grado);
  int getGradoIn();
  void addGradoIn();

  // Sobrecarga de operadores
  bool operator==(const ipOrden &) const;
  bool operator!=(const ipOrden &) const;
  bool operator>(const ipOrden &) const;
  bool operator<(const ipOrden &) const;
  bool operator>=(const ipOrden &) const;
  bool operator<=(const ipOrden &) const;

};




#endif // _IPORDEN_H