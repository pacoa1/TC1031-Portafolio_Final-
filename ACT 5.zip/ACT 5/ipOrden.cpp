#include "ipOrden.h"

// Constructor 
ipOrden::ipOrden(){
  ip = "";
  orden = 0;
  grado = 0;
  gradoIn = 0;
  ipnum = 0;
}

// Complejidad O(n)
// Constructor con parametros, además de que se hace la conversion de la IP 
ipOrden::ipOrden(std::string _ip, int _orden){
  ip = _ip;
  orden = _orden;
  grado = 0;
  gradoIn = 0;

  // Convertir IP
  int posInit = 0;
  int posFound = 0;
  std::string splitted;
  std::vector<std::string> results;   
  while(posFound >= 0) {
    posFound = ip.find(".", posInit);
    splitted = ip.substr(posInit, posFound - posInit);
    posInit = posFound + 1;
    results.push_back(splitted);
  }
  int partA = std::stoi(results[0]);
  int partB = std::stoi(results[1]);
  int partC = std::stoi(results[2]);
  int partD = std::stoi(results[3]);
  ipnum = partA*(pow(256,3)) + partB*(pow(256,2)) + partC*256 + partD;
}

// Complejidad O(1)
// Regresa la Ip en entero
unsigned int ipOrden::getIpNum(){
  return ipnum;
}

// Complejidad O(1)
// Regresa el orden en entero
int ipOrden::getOrden(){
  return orden;
}

// Complejidad O(1)
// set de grado
void ipOrden::setGrado(int _grado){
  grado = _grado;
}

// Complejidad O(1)
// Hace el aumento de grado en 1
void ipOrden::addGrado() {
  grado++;
}

// Complejidad O(1)
// Regresa el grado de la Ip
int ipOrden::getGrado(){
  return grado;
}

// Complejidad O(1)
// Regresa la Ip en string 
std::string ipOrden::getIpStr(){
  return ip;
}

// Complejidad O(1)
// set de grado de entrada de la Ip
void ipOrden::setGradoIn(int _grado){
  gradoIn = _grado;
}

// Complejidad O(1)
// Regresa el grado de entrada de la Ip
int ipOrden::getGradoIn(){
  return gradoIn;
}

// Complejidad O(1)
// Hace el aumento de grado de entrada en 1
void ipOrden::addGradoIn(){
  gradoIn++;
}

// Definimos la sobrecarga de operadores para la IP decimal
bool ipOrden::operator==(const ipOrden &other) const {
  return this->ipnum == other.ipnum;
}

bool ipOrden::operator!=(const ipOrden &other) const {
  return this->ipnum != other.ipnum;
}

bool ipOrden::operator>=(const ipOrden &other) const {
  return this->ipnum >= other.ipnum;
}

bool ipOrden::operator<=(const ipOrden &other) const {
  return this->ipnum <= other.ipnum;
}

bool ipOrden::operator>(const ipOrden &other) const {
  return this->ipnum > other.ipnum;
}

bool ipOrden::operator<(const ipOrden &other) const {
  return this->ipnum < other.ipnum;
}



